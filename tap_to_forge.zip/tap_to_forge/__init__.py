"""Top‑level package for the Tap‑to‑Forge application."""
