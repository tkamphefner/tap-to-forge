"""Package containing the smart contract code for Tap‑to‑Forge."""
