"""
Tap‑to‑Forge application logic for Algorand.

This PyTeal contract implements a simple clicker‑style game where players earn
units of an Algorand Standard Asset (WORK) by tapping a button. Each tap
produces a reward for the player and burns a fraction of the tokens to an
irrecoverable burn escrow. Players must first pay a one‑time entry fee in
Algos to unlock gameplay. All upgrades and actions after unlocking are paid
with the WORK token.

Changes from the original version:

* Added mobile friendliness is handled purely in the frontend (CSS) and does
  not affect this contract.
* Introduced a session/play timer with a cooldown: players may play for up to
  one hour per session. After one hour has elapsed the account enters a one
  hour cooldown during which taps are rejected. Once the cooldown expires a
  new session begins on the next tap and a fresh one‑hour window is opened.

The contract stores timestamps for when the current play window ends and
when the cooldown window ends in local state. These are checked at each
tap. If the current timestamp (from `Global.latest_timestamp()`) is less
than the cooldown end timestamp, the tap is rejected. Otherwise the
contract ensures a new session is started if necessary and proceeds to
distribute rewards and burn tokens as before.
"""

from pyteal import *


# ---------- Global keys ----------
G_ADMIN     = Bytes("admin")       # bytes: admin address
G_ASA_ID    = Bytes("asa_id")      # uint: WORK asset id
G_TREASURY  = Bytes("treasury")    # bytes: treasury addr
G_BURN      = Bytes("burn")        # bytes: burn escrow addr
G_ENTRY_FEE = Bytes("entry_fee")   # uint: microAlgos required (e.g., 2_000_000)
G_REWARD    = Bytes("reward")      # uint: WORK base units per tap (respect decimals)
G_BURN_BP   = Bytes("burn_bp")     # uint: burn basis points (0–10000)

# ---------- Local keys ----------
L_UNLOCKED     = Bytes("u")        # 0/1 gate to indicate the user has paid entry fee
L_LAST_TS      = Bytes("lt")       # last tap timestamp (for optional idle rewards)
L_END_PLAY     = Bytes("ep")       # timestamp when the current play window ends
L_COOL_UNTIL   = Bytes("cu")       # timestamp when cooldown ends; before this taps are blocked


def is_admin(sender: Expr) -> Expr:
    """Check if the transaction sender matches the stored admin address."""
    return sender == App.globalGet(G_ADMIN)


def assert_creator_only() -> Expr:
    """Assert that the current transaction sender is the contract creator/admin."""
    return Assert(is_admin(Txn.sender()))


def on_create() -> Expr:
    """On creation, initialise global values from the transaction fields."""
    return Seq(
        # Validate expected fields
        Assert(Txn.assets.length() == Int(1)),
        Assert(Txn.accounts.length() >= Int(3)),
        Assert(Txn.application_args.length() == Int(3)),

        # Store global data: creator/admin, ASA id, treasury, burn escrow, fee, reward, burn_bp
        App.globalPut(G_ADMIN, Txn.sender()),
        App.globalPut(G_ASA_ID, Txn.assets[0]),
        App.globalPut(G_TREASURY, Txn.accounts[1]),
        App.globalPut(G_BURN, Txn.accounts[2]),
        App.globalPut(G_ENTRY_FEE, Btoi(Txn.application_args[0])),
        App.globalPut(G_REWARD, Btoi(Txn.application_args[1])),
        App.globalPut(G_BURN_BP, Btoi(Txn.application_args[2])),
        Approve(),
    )


def on_opt_in() -> Expr:
    """Initialise local state for a new user opting into the app."""
    return Seq(
        App.localPut(Txn.sender(), L_UNLOCKED, Int(0)),
        App.localPut(Txn.sender(), L_LAST_TS, Global.latest_timestamp()),
        # Initialise end_play and cooldown to zero (not yet started)
        App.localPut(Txn.sender(), L_END_PLAY, Int(0)),
        App.localPut(Txn.sender(), L_COOL_UNTIL, Int(0)),
        Approve(),
    )


def method_selector(name: str) -> Bytes:
    """Return the method name as bytes. We use simple string selectors."""
    return Bytes(name)


def do_unlock() -> Expr:
    """Process a one‑time unlock payment. Must be called atomically with a payment txn."""
    fee   = App.globalGet(G_ENTRY_FEE)
    tres  = App.globalGet(G_TREASURY)
    idx   = Txn.group_index()
    return Seq(
        # Expect exactly two transactions: [0] payment, [1] app call
        Assert(Global.group_size() == Int(2)),
        Assert(idx == Int(1)),
        Assert(Gtxn[0].type_enum() == TxnType.Payment),
        Assert(Gtxn[0].sender() == Txn.sender()),
        Assert(Gtxn[0].receiver() == tres),
        Assert(Gtxn[0].amount() >= fee),

        # Mark unlocked
        App.localPut(Txn.sender(), L_UNLOCKED, Int(1)),
        Approve(),
    )


def do_app_optin_asset() -> Expr:
    """Admin-only call to have the app opt into the WORK asset."""
    return Seq(
        assert_creator_only(),
        InnerTxnBuilder.Begin(),
        InnerTxnBuilder.SetFields({
            TxnField.type_enum: TxnType.AssetTransfer,
            TxnField.xfer_asset: App.globalGet(G_ASA_ID),
            TxnField.asset_amount: Int(0),
            TxnField.asset_receiver: Global.current_application_address(),
        }),
        InnerTxnBuilder.Submit(),
        Approve(),
    )


def do_set_params() -> Expr:
    """Admin-only method to update entry_fee, reward and burn basis points."""
    return Seq(
        assert_creator_only(),
        Assert(Txn.application_args.length() == Int(4)),
        App.globalPut(G_ENTRY_FEE, Btoi(Txn.application_args[1])),
        App.globalPut(G_REWARD,    Btoi(Txn.application_args[2])),
        App.globalPut(G_BURN_BP,   Btoi(Txn.application_args[3])),
        Approve(),
    )


def do_tap() -> Expr:
    """Handle a tap. Enforce unlock, session play limit and cooldown, then distribute rewards."""
    asa     = App.globalGet(G_ASA_ID)
    burn_bp = App.globalGet(G_BURN_BP)
    reward  = App.globalGet(G_REWARD)

    burn_amt = WideRatio([reward, burn_bp], [Int(10000)])   # floor(basis point fraction)
    to_user  = reward - burn_amt

    now        = Global.latest_timestamp()
    end_play   = App.localGet(Txn.sender(), L_END_PLAY)
    cool_until = App.localGet(Txn.sender(), L_COOL_UNTIL)

    # Determine whether we need to start a new session. We start new if this is
    # the first tap (end_play == 0) or if the previous cooldown has expired. In
    # that case we set a fresh play window (1 hour) and a cooldown end (2 hours).
    start_new_session = Or(end_play == Int(0), now >= cool_until)

    return Seq(
        # Must be unlocked
        Assert(App.localGet(Txn.sender(), L_UNLOCKED) == Int(1)),
        # Reject if we are still in cooldown
        Assert(now >= cool_until),
        # Conditionally set up new session
        If(start_new_session).Then(
            Seq(
                App.localPut(Txn.sender(), L_END_PLAY, now + Int(3600)),
                App.localPut(Txn.sender(), L_COOL_UNTIL, now + Int(7200)),
            )
        ),
        # Reject if we have exceeded the play window (i.e. in between play end and cooldown end).
        # At this point, end_play > 0 and now >= cool_until has been handled. So if now > end_play
        # and now < cool_until, this tap is outside the play window. We reject.
        Assert(Or(now <= App.localGet(Txn.sender(), L_END_PLAY), start_new_session)),

        # Perform asset transfers to user and burn address
        InnerTxnBuilder.Begin(),
        InnerTxnBuilder.SetFields({
            TxnField.type_enum: TxnType.AssetTransfer,
            TxnField.xfer_asset: asa,
            TxnField.asset_amount: to_user,
            TxnField.asset_receiver: Txn.sender(),
        }),
        InnerTxnBuilder.Submit(),
        InnerTxnBuilder.Begin(),
        InnerTxnBuilder.SetFields({
            TxnField.type_enum: TxnType.AssetTransfer,
            TxnField.xfer_asset: asa,
            TxnField.asset_amount: burn_amt,
            TxnField.asset_receiver: App.globalGet(G_BURN),
        }),
        InnerTxnBuilder.Submit(),

        # Update last tap timestamp (optional idle reward logic could use this)
        App.localPut(Txn.sender(), L_LAST_TS, now),
        Approve(),
    )


def approval() -> Expr:
    """Main approval program dispatching logic based on transaction context."""
    method = Txn.application_args[0]
    return Cond(
        [Txn.application_id() == Int(0), on_create()],
        [Txn.on_completion() == OnComplete.OptIn, on_opt_in()],
        [Txn.on_completion() == OnComplete.NoOp, Cond(
            [method == method_selector("unlock"), do_unlock()],
            [method == method_selector("tap"),    do_tap()],
            [method == method_selector("app_optin_asset"), do_app_optin_asset()],
            [method == method_selector("set"), do_set_params()],
        )],
    )


def clear() -> Expr:
    """Simple clear state program that approves any clear state call."""
    return Approve()


if __name__ == "__main__":
    # When run directly, output the compiled TEAL for both approval and clear programs.
    print(compileTeal(approval(), mode=Mode.Application, version=8))
    print("----")
    print(compileTeal(clear(), mode=Mode.Application, version=8))