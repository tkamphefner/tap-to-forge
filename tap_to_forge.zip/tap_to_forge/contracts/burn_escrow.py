"""
Stateless logic signature for burning WORK tokens.

This program only allows a 0‑amount self asset transfer which serves as the
opt‑in transaction. Once the logic signature account has opted into the
WORK token it cannot send any tokens out. Any tokens sent to this account
are effectively removed from circulation (burned). The program also
rejects any attempt to rekey or close out the account.
"""

from pyteal import *


def burn_escrow() -> Expr:
    """Return the TEAL logic that enforces the burn escrow restrictions."""
    return And(
        # Do not allow rekeying
        Txn.rekey_to() == Global.zero_address(),
        # Keep fees bounded to a reasonable amount
        Txn.fee() <= Int(2000),
        # Only allow asset transfer transactions
        Txn.type_enum() == TxnType.AssetTransfer,
        # Only permit zero amount transfers (opt-in)
        Txn.asset_amount() == Int(0),
        # Sender and receiver must be the same address (self-transfer)
        Txn.asset_receiver() == Txn.sender(),
        # Clawback and close fields must be unset
        Txn.asset_sender() == Global.zero_address(),
        Txn.asset_close_to() == Global.zero_address(),
    )


if __name__ == "__main__":
    # Print TEAL code for inspection
    print(compileTeal(burn_escrow(), mode=Mode.Signature, version=6))