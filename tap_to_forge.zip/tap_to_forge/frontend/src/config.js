// Configuration for Tap‑to‑Forge frontend.
//
// Copy the values printed by the deploy script here once your application is
// deployed. The WORK_ASA_ID should be set to your asset's ID on the network
// being used (TestNet or MainNet). If you are developing on TestNet and
// deployed a separate ASA there, update the ID accordingly.

export const NETWORK = "TestNet"; // Set to "MainNet" when deploying to MainNet
export const ALGOD_URL = NETWORK === "MainNet"
  ? "https://mainnet-api.algonode.cloud"
  : "https://testnet-api.algonode.cloud";
export const INDEXER_URL = NETWORK === "MainNet"
  ? "https://mainnet-idx.algonode.cloud"
  : "https://testnet-idx.algonode.cloud";

// Replace APP_ID with the application ID printed by the deploy script
export const APP_ID = 0;

// Set WORK_ASA_ID to your asset ID on the current network
export const WORK_ASA_ID = 3189468904;

// Treasury address to which unlock fees are sent. Should match the treasury
// configured in the deployment.
export const TREASURY = "UIAD5462SRAVNNJUPPZD7AKROSLNPGSHP2YRI2GUWOEOOOAHPTDPPJRBAE";

// Fee in ALGO for unlocking gameplay. Must match the value in the app's
// global state (G_ENTRY_FEE) expressed in Algos (not microalgos).
export const UNLOCK_FEE_ALGOS = 2;