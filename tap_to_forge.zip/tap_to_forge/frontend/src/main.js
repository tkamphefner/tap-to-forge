import algosdk from "algosdk";
import PeraWalletConnect from "@perawallet/connect";
import {
  ALGOD_URL,
  INDEXER_URL,
  APP_ID,
  WORK_ASA_ID,
  TREASURY,
  UNLOCK_FEE_ALGOS,
} from "./config.js";

// Initialise Algorand clients
const peraWallet = new PeraWalletConnect();
const algod = new algosdk.Algodv2("", ALGOD_URL, "");
const indexer = new algosdk.Indexer("", INDEXER_URL, "");

let account = null;

// Utility for selecting elements
const $ = (id) => document.getElementById(id);

// Update status text and class
function setStatus(msg, cls = "") {
  const el = $("status");
  el.textContent = msg;
  el.className = `status ${cls}`;
}

// Convert Algos to microAlgos
function algosToMicro(a) {
  return Math.round(a * 1_000_000);
}

// Refresh UI based on current on-chain state
async function refreshState() {
  // Always disable action buttons until state is resolved
  $("optin").disabled = true;
  $("unlock").disabled = true;
  $("tap").disabled = true;

  if (!account) {
    $("acct").textContent = "—";
    $("workBal").textContent = "—";
    $("unlocked").textContent = "—";
    $("cooldown").textContent = "";
    return;
  }

  // Set account label
  $("acct").textContent = account;

  // Fetch WORK balance
  try {
    const info = await indexer
      .lookupAccountAssets(account)
      .assetId(WORK_ASA_ID)
      .do();
    const holding = info.assets?.[0];
    $("workBal").textContent = holding ? String(holding.amount) : "0";
  } catch {
    $("workBal").textContent = "0";
  }

  // Fetch local state for this app
  let unlocked = false;
  let endPlay = 0;
  let coolUntil = 0;
  try {
    const res = await indexer
      .lookupAccountAppLocalStates(account)
      .applicationID(APP_ID)
      .do();
    const kv = res["apps-local-states"]?.[0]?.["key-value"] || [];
    for (const entry of kv) {
      const key = atob(entry.key);
      const val = entry.value;
      if (key === "u") unlocked = val.uint === 1;
      else if (key === "ep") endPlay = val.uint;
      else if (key === "cu") coolUntil = val.uint;
    }
  } catch {
    // Not opted into app yet; state stays false/zero
  }
  $("unlocked").textContent = unlocked ? "yes" : "no";

  // Determine if account is opted into WORK (required before transfers)
  let hasAsset = false;
  try {
    const res = await indexer
      .lookupAccountAssets(account)
      .assetId(WORK_ASA_ID)
      .do();
    hasAsset = !!res.assets?.length;
  } catch {
    hasAsset = false;
  }

  // Compute cooldown remaining using local computer time for UI hints.
  const now = Math.floor(Date.now() / 1000);
  const cooldownRemaining = Math.max(0, coolUntil - now);
  if (cooldownRemaining > 0) {
    // Format to minutes:seconds (approx)
    const minutes = Math.floor(cooldownRemaining / 60);
    const seconds = cooldownRemaining % 60;
    $("cooldown").textContent = `Cooldown active: ${minutes}m ${seconds}s left`;
  } else {
    $("cooldown").textContent = "";
  }

  // Enable/disable buttons based on state
  $("optin").disabled = hasAsset || !account;
  $("unlock").disabled = !account || !hasAsset || unlocked;
  $("tap").disabled = !account || !hasAsset || !unlocked || cooldownRemaining > 0;
}

// Connect Pera Wallet
$("connect").onclick = async () => {
  try {
    const accts = await peraWallet.connect();
    peraWallet.connector?.on("disconnect", () => {
      account = null;
      setStatus("Wallet disconnected.", "warn");
      refreshState();
    });
    account = accts[0];
    setStatus("Connected. Please opt-in to WORK and unlock.", "ok");
    await refreshState();
  } catch (e) {
    console.error(e);
    setStatus("Connect canceled or failed.", "warn");
  }
};

// Opt into the WORK asset (ASA)
$("optin").onclick = async () => {
  if (!account) return;
  try {
    const sp = await algod.getTransactionParams().do();
    const axfer = algosdk.makeAssetTransferTxnWithSuggestedParamsFromObject({
      from: account,
      to: account,
      amount: 0,
      assetIndex: WORK_ASA_ID,
      suggestedParams: sp,
    });
    const [{ signedTxn }] = await peraWallet.signTransaction([axfer.toByte()]);
    const { txId } = await algod.sendRawTransaction(signedTxn).do();
    await waitForConfirmation(txId);
    setStatus("Opt-in complete.", "ok");
    await refreshState();
  } catch (e) {
    console.error(e);
    setStatus("Opt-in failed.", "warn");
  }
};

// Pay the entry fee and unlock the app
$("unlock").onclick = async () => {
  if (!account) return;
  try {
    const sp = await algod.getTransactionParams().do();
    const pay = algosdk.makePaymentTxnWithSuggestedParamsFromObject({
      from: account,
      to: TREASURY,
      amount: algosToMicro(UNLOCK_FEE_ALGOS),
      suggestedParams: sp,
    });
    const sp2 = await algod.getTransactionParams().do();
    sp2.flatFee = true;
    sp2.fee = 2000;
    const appCall = algosdk.makeApplicationNoOpTxnFromObject({
      from: account,
      appIndex: APP_ID,
      appArgs: [new Uint8Array(Buffer.from("unlock"))],
      suggestedParams: sp2,
    });
    algosdk.assignGroupID([pay, appCall]);
    const signed = await peraWallet.signTransaction([
      pay.toByte(),
      appCall.toByte(),
    ]);
    const txs = signed.map((s) => s.signedTxn);
    const { txId } = await algod.sendRawTransaction(txs).do();
    await waitForConfirmation(txId);
    setStatus("Unlocked! You can now tap.", "ok");
    await refreshState();
  } catch (e) {
    console.error(e);
    setStatus("Unlock failed.", "warn");
  }
};

// Perform a tap (call the smart contract)
$("tap").onclick = async () => {
  if (!account) return;
  try {
    const sp = await algod.getTransactionParams().do();
    sp.flatFee = true;
    // Fee must cover the cost of two inner transactions
    sp.fee = 3000;
    const appCall = algosdk.makeApplicationNoOpTxnFromObject({
      from: account,
      appIndex: APP_ID,
      appArgs: [new Uint8Array(Buffer.from("tap"))],
      suggestedParams: sp,
    });
    const [{ signedTxn }] = await peraWallet.signTransaction([appCall.toByte()]);
    const { txId } = await algod.sendRawTransaction(signedTxn).do();
    await waitForConfirmation(txId);
    setStatus("Forge successful! WORK sent and burned.", "ok");
    await refreshState();
  } catch (e) {
    console.error(e);
    if (String(e).includes("rejected")) {
      setStatus("Tap rejected – you may be in cooldown or have not unlocked.", "warn");
    } else {
      setStatus("Tap failed.", "warn");
    }
  }
};

// Helper: wait for tx confirmation
async function waitForConfirmation(txId) {
  let last = (await algod.status().do())["last-round"];
  while (true) {
    const p = await algod.pendingTransactionInformation(txId).do();
    if (p["confirmed-round"]) return p;
    last++;
    await algod.statusAfterBlock(last).do();
  }
}

// Periodically refresh the UI
setInterval(refreshState, 4000);

// Initial call
refreshState();