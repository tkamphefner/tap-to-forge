"""
Deployment script for the Tap‑to‑Forge Algorand application.

This script compiles and deploys the stateful smart contract defined in
``tap_to_forge/contracts/app.py`` and the stateless burn escrow defined in
``tap_to_forge/contracts/burn_escrow.py``. It also handles funding and
asset opt‑in for the burn escrow and the application account, and seeds the
application with a supply of WORK tokens for rewards.

Environment variables used:

* ``CREATOR_MNEMONIC`` – mnemonic for the admin/creator account which will
  deploy the application.
* ``TREASURY_MNEMONIC`` – mnemonic for the account holding the supply of
  WORK tokens (optional; required if seeding the app automatically).
* ``ALGOD_URL`` – endpoint of the Algod node to connect to (defaults to
  Algonode TestNet).
* ``ALGOD_TOKEN`` – API token for the Algod node (Algonode does not
  require a token).

It also defines some configuration values at the top of the file which can
be customised to target TestNet or MainNet and to set the reward, entry
fee, burn ratio and seed amounts.
"""

import base64
import os
import sys
from typing import Tuple

from algosdk import account, mnemonic
from algosdk.v2client import algod
from algosdk.future import transaction as tx
from algosdk.logic import get_application_address, LogicSigAccount


# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------

# Algod connection settings. Defaults to TestNet endpoints on Algonode. You can
# override these with environment variables.
ALGOD = os.getenv("ALGOD_URL", "https://testnet-api.algonode.cloud")
ALGOD_TOKEN = os.getenv("ALGOD_TOKEN", "")  # Algonode does not require a token

# Mnemonics for the creator/admin and treasury (optional for seeding)
CREATOR_MNEMONIC = os.getenv("CREATOR_MNEMONIC")
TREASURY_MNEMONIC = os.getenv("TREASURY_MNEMONIC")

# The ASA ID for WORK. Set to your asset ID on the relevant network.
WORK_ASA_ID = int(os.getenv("WORK_ASA_ID", "3189468904"))

# The treasury account address which receives ALGO entry fees and holds WORK.
# This should match the reserve or a distribution address for your ASA.
TREASURY_ADDR = os.getenv(
    "TREASURY_ADDR",
    "UIAD5462SRAVNNJUPPZD7AKROSLNPGSHP2YRI2GUWOEOOOAHPTDPPJRBAE",
)

# Game economy parameters. Adjust these values to tune your game.
ENTRY_FEE_ALGOS = int(os.getenv("ENTRY_FEE_MICROALGOS", "2000000"))  # 2 ALGO in microalgos
REWARD_PER_TAP_UNITS = int(os.getenv("REWARD_PER_TAP_UNITS", "1000000"))  # 1 WORK (with 6 decimals)
BURN_BASIS_POINTS = int(os.getenv("BURN_BASIS_POINTS", "2000"))  # 20% burn

# Seed amount: how many WORK units to seed into the app account so it can pay
# rewards. Adjust according to your supply and expected gameplay.
SEED_WORK_TO_APP = int(os.getenv("SEED_WORK_TO_APP", "5000000000"))  # e.g. 5,000 WORK if 6 decimals


def algod_client() -> algod.AlgodClient:
    """Instantiate and return an Algod client."""
    return algod.AlgodClient(ALGOD_TOKEN, ALGOD)


def compile_teal(client: algod.AlgodClient, teal_source: str) -> bytes:
    """Compile TEAL source code via the node and return raw bytes."""
    res = client.compile(teal_source)
    return base64.b64decode(res["result"])


def acct_from_mnemonic(mn: str) -> Tuple[str, str]:
    """Return (address, private_key) from a 25‑word mnemonic."""
    sk = mnemonic.to_private_key(mn)
    addr = account.address_from_private_key(sk)
    return addr, sk


def wait(client: algod.AlgodClient, txid: str) -> dict:
    """Wait for a transaction to be confirmed and return the pending info."""
    last = client.status()["last-round"]
    while True:
        try:
            p = client.pending_transaction_info(txid)
            if p.get("confirmed-round", 0) > 0:
                return p
        except Exception:
            pass
        last += 1
        client.status_after_block(last)


def to_bytes_u64(i: int) -> bytes:
    """Encode an integer as an 8‑byte big‑endian byte sequence."""
    return i.to_bytes(8, "big")


# -----------------------------------------------------------------------------
# Burn escrow creation and opt-in
# -----------------------------------------------------------------------------


def create_burn_escrow(client: algod.AlgodClient) -> Tuple[str, LogicSigAccount]:
    """Compile the burn escrow TEAL and return the address and LogicSig object."""
    from pyteal import compileTeal, Mode
    from tap_to_forge.contracts.burn_escrow import burn_escrow as burn_prog

    teal_str = compileTeal(burn_prog(), Mode.Signature, version=6)
    program = compile_teal(client, teal_str)
    lsig = LogicSigAccount(program)
    return lsig.address(), lsig


def fund_and_optin_burn_escrow(
    client: algod.AlgodClient, creator_sk: str, burn_addr: str, lsig: LogicSigAccount
) -> None:
    """Fund the burn escrow account and opt it into the WORK asset."""
    creator_addr = account.address_from_private_key(creator_sk)
    sp = client.suggested_params()

    # Fund min balance (0.2 ALGO covers base + ASA opt-in and fees)
    pay_txn = tx.PaymentTxn(creator_addr, sp, burn_addr, 200_000)
    signed_pay = pay_txn.sign(creator_sk)
    client.send_transaction(signed_pay)
    wait(client, signed_pay.get_txid())

    # Opt-in to WORK (0‑amount transfer to self)
    sp = client.suggested_params()
    axfer = tx.AssetTransferTxn(
        sender=burn_addr,
        sp=sp,
        receiver=burn_addr,
        amt=0,
        index=WORK_ASA_ID,
    )
    stx = tx.LogicSigTransaction(axfer, lsig)
    client.send_transaction(stx)
    wait(client, stx.get_txid())


# -----------------------------------------------------------------------------
# Application deployment
# -----------------------------------------------------------------------------


def deploy_app(
    client: algod.AlgodClient,
    creator_sk: str,
    burn_addr: str,
) -> Tuple[int, str]:
    """Compile and deploy the stateful application; return (app_id, app_address)."""
    from pyteal import compileTeal, Mode
    from tap_to_forge.contracts.app import approval, clear

    # Compile approval and clear programs to TEAL
    approval_teal = compileTeal(approval(), Mode.Application, version=8)
    clear_teal = compileTeal(clear(), Mode.Application, version=8)
    approval_b = compile_teal(client, approval_teal)
    clear_b = compile_teal(client, clear_teal)

    # Define global and local state schemas
    global_schema = tx.StateSchema(num_uints=4, num_byte_slices=3)
    # Local state: unlocked, last_ts, end_play, cooldown_until (4 uints)
    local_schema = tx.StateSchema(num_uints=4, num_byte_slices=0)

    sp = client.suggested_params()
    creator_addr = account.address_from_private_key(creator_sk)

    app_args = [
        to_bytes_u64(ENTRY_FEE_ALGOS),
        to_bytes_u64(REWARD_PER_TAP_UNITS),
        to_bytes_u64(BURN_BASIS_POINTS),
    ]

    # The accounts array: [0] sender (implicit), [1] treasury, [2] burn escrow
    txn = tx.ApplicationCreateTxn(
        sender=creator_addr,
        sp=sp,
        on_complete=tx.OnComplete.NoOpOC,
        approval_program=approval_b,
        clear_program=clear_b,
        global_schema=global_schema,
        local_schema=local_schema,
        foreign_assets=[WORK_ASA_ID],
        accounts=[TREASURY_ADDR, burn_addr],
        app_args=app_args,
    )
    stx = txn.sign(creator_sk)
    client.send_transaction(stx)
    res = wait(client, stx.get_txid())
    app_id = res["application-index"]
    app_addr = get_application_address(app_id)
    return app_id, app_addr


def app_optin_asset(client: algod.AlgodClient, creator_sk: str, app_id: int) -> None:
    """Have the application account opt in to the WORK asset (admin-only)."""
    creator_addr = account.address_from_private_key(creator_sk)
    sp = client.suggested_params()
    # Flat fee covers inner transaction cost
    sp.flat_fee = True
    sp.fee = 2000
    txn = tx.ApplicationNoOpTxn(
        sender=creator_addr,
        sp=sp,
        index=app_id,
        app_args=[b"app_optin_asset"],
    )
    stx = txn.sign(creator_sk)
    client.send_transaction(stx)
    wait(client, stx.get_txid())


def seed_app_with_work(
    client: algod.AlgodClient,
    treasury_mn: str,
    app_addr: str,
    amount_units: int,
) -> None:
    """Transfer a supply of WORK from treasury to the app account for rewards."""
    tres_addr, tres_sk = acct_from_mnemonic(treasury_mn)
    if tres_addr != TREASURY_ADDR:
        print("WARNING: Provided treasury mnemonic does not match TREASURY_ADDR!")
    sp = client.suggested_params()
    axfer = tx.AssetTransferTxn(
        sender=tres_addr,
        sp=sp,
        receiver=app_addr,
        amt=amount_units,
        index=WORK_ASA_ID,
    )
    stx = axfer.sign(tres_sk)
    client.send_transaction(stx)
    wait(client, stx.get_txid())


def main() -> None:
    if not CREATOR_MNEMONIC:
        print("Error: CREATOR_MNEMONIC environment variable must be set.")
        sys.exit(1)
    client = algod_client()
    creator_addr, creator_sk = acct_from_mnemonic(CREATOR_MNEMONIC)
    print(f"Creator address: {creator_addr}")

    # 1) Create burn escrow logic sig and opt-in
    print("Creating burn escrow...")
    burn_addr, lsig = create_burn_escrow(client)
    print(f"Burn escrow address: {burn_addr}")
    print("Funding and opting in burn escrow...")
    fund_and_optin_burn_escrow(client, creator_sk, burn_addr, lsig)

    # 2) Deploy the stateful application
    print("Deploying application...")
    app_id, app_addr = deploy_app(client, creator_sk, burn_addr)
    print(f"Deployed app ID: {app_id}")
    print(f"App address: {app_addr}")

    # 3) Fund the app account with some Algo for min balance and call opt-in to WORK
    sp = client.suggested_params()
    # Provide enough ALGO to cover min balance (0.5 ALGO leaves room for inner txns)
    pay_txn = tx.PaymentTxn(creator_addr, sp, app_addr, 500_000)
    stx = pay_txn.sign(creator_sk)
    client.send_transaction(stx)
    wait(client, stx.get_txid())
    print("Funded app with Algo for min balance.")

    print("App opting into WORK asset...")
    app_optin_asset(client, creator_sk, app_id)
    print("App is now opted into WORK.")

    # 4) Seed the app account with WORK from the treasury, if provided
    if TREASURY_MNEMONIC:
        print(f"Seeding app with {SEED_WORK_TO_APP} units of WORK from treasury...")
        seed_app_with_work(client, TREASURY_MNEMONIC, app_addr, SEED_WORK_TO_APP)
        print("Seed complete.")
    else:
        print("Note: TREASURY_MNEMONIC not provided; skipping seeding.")

    print("\n=== Deployment complete ===")
    print(f"APP_ID={app_id}")
    print(f"APP_ADDRESS={app_addr}")
    print(f"BURN_ESCROW_ADDRESS={burn_addr}")


if __name__ == "__main__":
    main()